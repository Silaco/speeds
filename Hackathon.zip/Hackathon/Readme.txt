http://proxy.ebiz.verizon.com:80

Host: ec2-52-32-74-129.us-west-2.compute.amazonaws.com
User: ec2-user
Switch to Root: sudo su

AWS Console
User: sramji1982@gmail.com
Pwd: 123456ab
